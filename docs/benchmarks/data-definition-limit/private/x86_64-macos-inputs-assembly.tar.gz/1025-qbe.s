.data
.balign 1
.globl _entry_0
_entry_0:
	.byte 19
/* end data */

.data
.balign 2
.globl _entry_1
_entry_1:
	.short 380
/* end data */

.data
.balign 4
.globl _entry_2
_entry_2:
	.int 2147614726
/* end data */

.data
.balign 8
.globl _entry_3
_entry_3:
	.quad -81985529222004733
/* end data */

.data
.balign 16
.globl _entry_4
_entry_4:
	.int 1065353220
/* end data */

.data
.balign 32
.globl _entry_5
_entry_5:
	.quad 4607182418800017413
/* end data */

.bss
.balign 64
.globl _entry_6
_entry_6:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_7
_entry_7:
	.ascii "catalog-0007"
/* end data */

.data
.balign 64
.globl _entry_8
_entry_8:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_9
_entry_9:
	.byte 96
/* end data */

.data
.balign 2
.globl _entry_10
_entry_10:
	.short 2693
/* end data */

.data
.balign 4
.globl _entry_11
_entry_11:
	.int 2148204577
/* end data */

.data
.balign 8
.globl _entry_12
_entry_12:
	.quad -81985529222004724
/* end data */

.data
.balign 16
.globl _entry_13
_entry_13:
	.int 1065353229
/* end data */

.data
.balign 32
.globl _entry_14
_entry_14:
	.quad 4607182418800017422
/* end data */

.bss
.balign 64
.globl _entry_15
_entry_15:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_16
_entry_16:
	.ascii "catalog-0016"
/* end data */

.data
.balign 64
.globl _entry_17
_entry_17:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_18
_entry_18:
	.byte 173
/* end data */

.data
.balign 2
.globl _entry_19
_entry_19:
	.short 5006
/* end data */

.data
.balign 4
.globl _entry_20
_entry_20:
	.int 2148794428
/* end data */

.data
.balign 8
.globl _entry_21
_entry_21:
	.quad -81985529222004715
/* end data */

.data
.balign 16
.globl _entry_22
_entry_22:
	.int 1065353238
/* end data */

.data
.balign 32
.globl _entry_23
_entry_23:
	.quad 4607182418800017431
/* end data */

.bss
.balign 64
.globl _entry_24
_entry_24:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_25
_entry_25:
	.ascii "catalog-0025"
/* end data */

.data
.balign 64
.globl _entry_26
_entry_26:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_27
_entry_27:
	.byte 250
/* end data */

.data
.balign 2
.globl _entry_28
_entry_28:
	.short 7319
/* end data */

.data
.balign 4
.globl _entry_29
_entry_29:
	.int 2149384279
/* end data */

.data
.balign 8
.globl _entry_30
_entry_30:
	.quad -81985529222004706
/* end data */

.data
.balign 16
.globl _entry_31
_entry_31:
	.int 1065353247
/* end data */

.data
.balign 32
.globl _entry_32
_entry_32:
	.quad 4607182418800017440
/* end data */

.bss
.balign 64
.globl _entry_33
_entry_33:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_34
_entry_34:
	.ascii "catalog-0034"
/* end data */

.data
.balign 64
.globl _entry_35
_entry_35:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_36
_entry_36:
	.byte 71
/* end data */

.data
.balign 2
.globl _entry_37
_entry_37:
	.short 9632
/* end data */

.data
.balign 4
.globl _entry_38
_entry_38:
	.int 2149974130
/* end data */

.data
.balign 8
.globl _entry_39
_entry_39:
	.quad -81985529222004697
/* end data */

.data
.balign 16
.globl _entry_40
_entry_40:
	.int 1065353256
/* end data */

.data
.balign 32
.globl _entry_41
_entry_41:
	.quad 4607182418800017449
/* end data */

.bss
.balign 64
.globl _entry_42
_entry_42:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_43
_entry_43:
	.ascii "catalog-0043"
/* end data */

.data
.balign 64
.globl _entry_44
_entry_44:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_45
_entry_45:
	.byte 148
/* end data */

.data
.balign 2
.globl _entry_46
_entry_46:
	.short 11945
/* end data */

.data
.balign 4
.globl _entry_47
_entry_47:
	.int 2150563981
/* end data */

.data
.balign 8
.globl _entry_48
_entry_48:
	.quad -81985529222004688
/* end data */

.data
.balign 16
.globl _entry_49
_entry_49:
	.int 1065353265
/* end data */

.data
.balign 32
.globl _entry_50
_entry_50:
	.quad 4607182418800017458
/* end data */

.bss
.balign 64
.globl _entry_51
_entry_51:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_52
_entry_52:
	.ascii "catalog-0052"
/* end data */

.data
.balign 64
.globl _entry_53
_entry_53:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_54
_entry_54:
	.byte 225
/* end data */

.data
.balign 2
.globl _entry_55
_entry_55:
	.short 14258
/* end data */

.data
.balign 4
.globl _entry_56
_entry_56:
	.int 2151153832
/* end data */

.data
.balign 8
.globl _entry_57
_entry_57:
	.quad -81985529222004679
/* end data */

.data
.balign 16
.globl _entry_58
_entry_58:
	.int 1065353274
/* end data */

.data
.balign 32
.globl _entry_59
_entry_59:
	.quad 4607182418800017467
/* end data */

.bss
.balign 64
.globl _entry_60
_entry_60:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_61
_entry_61:
	.ascii "catalog-0061"
/* end data */

.data
.balign 64
.globl _entry_62
_entry_62:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_63
_entry_63:
	.byte 46
/* end data */

.data
.balign 2
.globl _entry_64
_entry_64:
	.short 16571
/* end data */

.data
.balign 4
.globl _entry_65
_entry_65:
	.int 2151743683
/* end data */

.data
.balign 8
.globl _entry_66
_entry_66:
	.quad -81985529222004670
/* end data */

.data
.balign 16
.globl _entry_67
_entry_67:
	.int 1065353283
/* end data */

.data
.balign 32
.globl _entry_68
_entry_68:
	.quad 4607182418800017476
/* end data */

.bss
.balign 64
.globl _entry_69
_entry_69:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_70
_entry_70:
	.ascii "catalog-0070"
/* end data */

.data
.balign 64
.globl _entry_71
_entry_71:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_72
_entry_72:
	.byte 123
/* end data */

.data
.balign 2
.globl _entry_73
_entry_73:
	.short 18884
/* end data */

.data
.balign 4
.globl _entry_74
_entry_74:
	.int 2152333534
/* end data */

.data
.balign 8
.globl _entry_75
_entry_75:
	.quad -81985529222004661
/* end data */

.data
.balign 16
.globl _entry_76
_entry_76:
	.int 1065353292
/* end data */

.data
.balign 32
.globl _entry_77
_entry_77:
	.quad 4607182418800017485
/* end data */

.bss
.balign 64
.globl _entry_78
_entry_78:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_79
_entry_79:
	.ascii "catalog-0079"
/* end data */

.data
.balign 64
.globl _entry_80
_entry_80:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_81
_entry_81:
	.byte 200
/* end data */

.data
.balign 2
.globl _entry_82
_entry_82:
	.short 21197
/* end data */

.data
.balign 4
.globl _entry_83
_entry_83:
	.int 2152923385
/* end data */

.data
.balign 8
.globl _entry_84
_entry_84:
	.quad -81985529222004652
/* end data */

.data
.balign 16
.globl _entry_85
_entry_85:
	.int 1065353301
/* end data */

.data
.balign 32
.globl _entry_86
_entry_86:
	.quad 4607182418800017494
/* end data */

.bss
.balign 64
.globl _entry_87
_entry_87:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_88
_entry_88:
	.ascii "catalog-0088"
/* end data */

.data
.balign 64
.globl _entry_89
_entry_89:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_90
_entry_90:
	.byte 21
/* end data */

.data
.balign 2
.globl _entry_91
_entry_91:
	.short 23510
/* end data */

.data
.balign 4
.globl _entry_92
_entry_92:
	.int 2153513236
/* end data */

.data
.balign 8
.globl _entry_93
_entry_93:
	.quad -81985529222004643
/* end data */

.data
.balign 16
.globl _entry_94
_entry_94:
	.int 1065353310
/* end data */

.data
.balign 32
.globl _entry_95
_entry_95:
	.quad 4607182418800017503
/* end data */

.bss
.balign 64
.globl _entry_96
_entry_96:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_97
_entry_97:
	.ascii "catalog-0097"
/* end data */

.data
.balign 64
.globl _entry_98
_entry_98:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_99
_entry_99:
	.byte 98
/* end data */

.data
.balign 2
.globl _entry_100
_entry_100:
	.short 25823
/* end data */

.data
.balign 4
.globl _entry_101
_entry_101:
	.int 2154103087
/* end data */

.data
.balign 8
.globl _entry_102
_entry_102:
	.quad -81985529222004634
/* end data */

.data
.balign 16
.globl _entry_103
_entry_103:
	.int 1065353319
/* end data */

.data
.balign 32
.globl _entry_104
_entry_104:
	.quad 4607182418800017512
/* end data */

.bss
.balign 64
.globl _entry_105
_entry_105:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_106
_entry_106:
	.ascii "catalog-0106"
/* end data */

.data
.balign 64
.globl _entry_107
_entry_107:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_108
_entry_108:
	.byte 175
/* end data */

.data
.balign 2
.globl _entry_109
_entry_109:
	.short 28136
/* end data */

.data
.balign 4
.globl _entry_110
_entry_110:
	.int 2154692938
/* end data */

.data
.balign 8
.globl _entry_111
_entry_111:
	.quad -81985529222004625
/* end data */

.data
.balign 16
.globl _entry_112
_entry_112:
	.int 1065353328
/* end data */

.data
.balign 32
.globl _entry_113
_entry_113:
	.quad 4607182418800017521
/* end data */

.bss
.balign 64
.globl _entry_114
_entry_114:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_115
_entry_115:
	.ascii "catalog-0115"
/* end data */

.data
.balign 64
.globl _entry_116
_entry_116:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_117
_entry_117:
	.byte 252
/* end data */

.data
.balign 2
.globl _entry_118
_entry_118:
	.short 30449
/* end data */

.data
.balign 4
.globl _entry_119
_entry_119:
	.int 2155282789
/* end data */

.data
.balign 8
.globl _entry_120
_entry_120:
	.quad -81985529222004616
/* end data */

.data
.balign 16
.globl _entry_121
_entry_121:
	.int 1065353337
/* end data */

.data
.balign 32
.globl _entry_122
_entry_122:
	.quad 4607182418800017530
/* end data */

.bss
.balign 64
.globl _entry_123
_entry_123:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_124
_entry_124:
	.ascii "catalog-0124"
/* end data */

.data
.balign 64
.globl _entry_125
_entry_125:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_126
_entry_126:
	.byte 73
/* end data */

.data
.balign 2
.globl _entry_127
_entry_127:
	.short 32762
/* end data */

.data
.balign 4
.globl _entry_128
_entry_128:
	.int 2155872640
/* end data */

.data
.balign 8
.globl _entry_129
_entry_129:
	.quad -81985529222004607
/* end data */

.data
.balign 16
.globl _entry_130
_entry_130:
	.int 1065353346
/* end data */

.data
.balign 32
.globl _entry_131
_entry_131:
	.quad 4607182418800017539
/* end data */

.bss
.balign 64
.globl _entry_132
_entry_132:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_133
_entry_133:
	.ascii "catalog-0133"
/* end data */

.data
.balign 64
.globl _entry_134
_entry_134:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_135
_entry_135:
	.byte 150
/* end data */

.data
.balign 2
.globl _entry_136
_entry_136:
	.short 35075
/* end data */

.data
.balign 4
.globl _entry_137
_entry_137:
	.int 2156462491
/* end data */

.data
.balign 8
.globl _entry_138
_entry_138:
	.quad -81985529222004598
/* end data */

.data
.balign 16
.globl _entry_139
_entry_139:
	.int 1065353355
/* end data */

.data
.balign 32
.globl _entry_140
_entry_140:
	.quad 4607182418800017548
/* end data */

.bss
.balign 64
.globl _entry_141
_entry_141:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_142
_entry_142:
	.ascii "catalog-0142"
/* end data */

.data
.balign 64
.globl _entry_143
_entry_143:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_144
_entry_144:
	.byte 227
/* end data */

.data
.balign 2
.globl _entry_145
_entry_145:
	.short 37388
/* end data */

.data
.balign 4
.globl _entry_146
_entry_146:
	.int 2157052342
/* end data */

.data
.balign 8
.globl _entry_147
_entry_147:
	.quad -81985529222004589
/* end data */

.data
.balign 16
.globl _entry_148
_entry_148:
	.int 1065353364
/* end data */

.data
.balign 32
.globl _entry_149
_entry_149:
	.quad 4607182418800017557
/* end data */

.bss
.balign 64
.globl _entry_150
_entry_150:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_151
_entry_151:
	.ascii "catalog-0151"
/* end data */

.data
.balign 64
.globl _entry_152
_entry_152:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_153
_entry_153:
	.byte 48
/* end data */

.data
.balign 2
.globl _entry_154
_entry_154:
	.short 39701
/* end data */

.data
.balign 4
.globl _entry_155
_entry_155:
	.int 2157642193
/* end data */

.data
.balign 8
.globl _entry_156
_entry_156:
	.quad -81985529222004580
/* end data */

.data
.balign 16
.globl _entry_157
_entry_157:
	.int 1065353373
/* end data */

.data
.balign 32
.globl _entry_158
_entry_158:
	.quad 4607182418800017566
/* end data */

.bss
.balign 64
.globl _entry_159
_entry_159:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_160
_entry_160:
	.ascii "catalog-0160"
/* end data */

.data
.balign 64
.globl _entry_161
_entry_161:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_162
_entry_162:
	.byte 125
/* end data */

.data
.balign 2
.globl _entry_163
_entry_163:
	.short 42014
/* end data */

.data
.balign 4
.globl _entry_164
_entry_164:
	.int 2158232044
/* end data */

.data
.balign 8
.globl _entry_165
_entry_165:
	.quad -81985529222004571
/* end data */

.data
.balign 16
.globl _entry_166
_entry_166:
	.int 1065353382
/* end data */

.data
.balign 32
.globl _entry_167
_entry_167:
	.quad 4607182418800017575
/* end data */

.bss
.balign 64
.globl _entry_168
_entry_168:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_169
_entry_169:
	.ascii "catalog-0169"
/* end data */

.data
.balign 64
.globl _entry_170
_entry_170:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_171
_entry_171:
	.byte 202
/* end data */

.data
.balign 2
.globl _entry_172
_entry_172:
	.short 44327
/* end data */

.data
.balign 4
.globl _entry_173
_entry_173:
	.int 2158821895
/* end data */

.data
.balign 8
.globl _entry_174
_entry_174:
	.quad -81985529222004562
/* end data */

.data
.balign 16
.globl _entry_175
_entry_175:
	.int 1065353391
/* end data */

.data
.balign 32
.globl _entry_176
_entry_176:
	.quad 4607182418800017584
/* end data */

.bss
.balign 64
.globl _entry_177
_entry_177:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_178
_entry_178:
	.ascii "catalog-0178"
/* end data */

.data
.balign 64
.globl _entry_179
_entry_179:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_180
_entry_180:
	.byte 23
/* end data */

.data
.balign 2
.globl _entry_181
_entry_181:
	.short 46640
/* end data */

.data
.balign 4
.globl _entry_182
_entry_182:
	.int 2159411746
/* end data */

.data
.balign 8
.globl _entry_183
_entry_183:
	.quad -81985529222004553
/* end data */

.data
.balign 16
.globl _entry_184
_entry_184:
	.int 1065353400
/* end data */

.data
.balign 32
.globl _entry_185
_entry_185:
	.quad 4607182418800017593
/* end data */

.bss
.balign 64
.globl _entry_186
_entry_186:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_187
_entry_187:
	.ascii "catalog-0187"
/* end data */

.data
.balign 64
.globl _entry_188
_entry_188:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_189
_entry_189:
	.byte 100
/* end data */

.data
.balign 2
.globl _entry_190
_entry_190:
	.short 48953
/* end data */

.data
.balign 4
.globl _entry_191
_entry_191:
	.int 2160001597
/* end data */

.data
.balign 8
.globl _entry_192
_entry_192:
	.quad -81985529222004544
/* end data */

.data
.balign 16
.globl _entry_193
_entry_193:
	.int 1065353409
/* end data */

.data
.balign 32
.globl _entry_194
_entry_194:
	.quad 4607182418800017602
/* end data */

.bss
.balign 64
.globl _entry_195
_entry_195:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_196
_entry_196:
	.ascii "catalog-0196"
/* end data */

.data
.balign 64
.globl _entry_197
_entry_197:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_198
_entry_198:
	.byte 177
/* end data */

.data
.balign 2
.globl _entry_199
_entry_199:
	.short 51266
/* end data */

.data
.balign 4
.globl _entry_200
_entry_200:
	.int 2160591448
/* end data */

.data
.balign 8
.globl _entry_201
_entry_201:
	.quad -81985529222004535
/* end data */

.data
.balign 16
.globl _entry_202
_entry_202:
	.int 1065353418
/* end data */

.data
.balign 32
.globl _entry_203
_entry_203:
	.quad 4607182418800017611
/* end data */

.bss
.balign 64
.globl _entry_204
_entry_204:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_205
_entry_205:
	.ascii "catalog-0205"
/* end data */

.data
.balign 64
.globl _entry_206
_entry_206:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_207
_entry_207:
	.byte 254
/* end data */

.data
.balign 2
.globl _entry_208
_entry_208:
	.short 53579
/* end data */

.data
.balign 4
.globl _entry_209
_entry_209:
	.int 2161181299
/* end data */

.data
.balign 8
.globl _entry_210
_entry_210:
	.quad -81985529222004526
/* end data */

.data
.balign 16
.globl _entry_211
_entry_211:
	.int 1065353427
/* end data */

.data
.balign 32
.globl _entry_212
_entry_212:
	.quad 4607182418800017620
/* end data */

.bss
.balign 64
.globl _entry_213
_entry_213:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_214
_entry_214:
	.ascii "catalog-0214"
/* end data */

.data
.balign 64
.globl _entry_215
_entry_215:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_216
_entry_216:
	.byte 75
/* end data */

.data
.balign 2
.globl _entry_217
_entry_217:
	.short 55892
/* end data */

.data
.balign 4
.globl _entry_218
_entry_218:
	.int 2161771150
/* end data */

.data
.balign 8
.globl _entry_219
_entry_219:
	.quad -81985529222004517
/* end data */

.data
.balign 16
.globl _entry_220
_entry_220:
	.int 1065353436
/* end data */

.data
.balign 32
.globl _entry_221
_entry_221:
	.quad 4607182418800017629
/* end data */

.bss
.balign 64
.globl _entry_222
_entry_222:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_223
_entry_223:
	.ascii "catalog-0223"
/* end data */

.data
.balign 64
.globl _entry_224
_entry_224:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_225
_entry_225:
	.byte 152
/* end data */

.data
.balign 2
.globl _entry_226
_entry_226:
	.short 58205
/* end data */

.data
.balign 4
.globl _entry_227
_entry_227:
	.int 2162361001
/* end data */

.data
.balign 8
.globl _entry_228
_entry_228:
	.quad -81985529222004508
/* end data */

.data
.balign 16
.globl _entry_229
_entry_229:
	.int 1065353445
/* end data */

.data
.balign 32
.globl _entry_230
_entry_230:
	.quad 4607182418800017638
/* end data */

.bss
.balign 64
.globl _entry_231
_entry_231:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_232
_entry_232:
	.ascii "catalog-0232"
/* end data */

.data
.balign 64
.globl _entry_233
_entry_233:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_234
_entry_234:
	.byte 229
/* end data */

.data
.balign 2
.globl _entry_235
_entry_235:
	.short 60518
/* end data */

.data
.balign 4
.globl _entry_236
_entry_236:
	.int 2162950852
/* end data */

.data
.balign 8
.globl _entry_237
_entry_237:
	.quad -81985529222004499
/* end data */

.data
.balign 16
.globl _entry_238
_entry_238:
	.int 1065353454
/* end data */

.data
.balign 32
.globl _entry_239
_entry_239:
	.quad 4607182418800017647
/* end data */

.bss
.balign 64
.globl _entry_240
_entry_240:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_241
_entry_241:
	.ascii "catalog-0241"
/* end data */

.data
.balign 64
.globl _entry_242
_entry_242:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_243
_entry_243:
	.byte 50
/* end data */

.data
.balign 2
.globl _entry_244
_entry_244:
	.short 62831
/* end data */

.data
.balign 4
.globl _entry_245
_entry_245:
	.int 2163540703
/* end data */

.data
.balign 8
.globl _entry_246
_entry_246:
	.quad -81985529222004490
/* end data */

.data
.balign 16
.globl _entry_247
_entry_247:
	.int 1065353463
/* end data */

.data
.balign 32
.globl _entry_248
_entry_248:
	.quad 4607182418800017656
/* end data */

.bss
.balign 64
.globl _entry_249
_entry_249:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_250
_entry_250:
	.ascii "catalog-0250"
/* end data */

.data
.balign 64
.globl _entry_251
_entry_251:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_252
_entry_252:
	.byte 127
/* end data */

.data
.balign 2
.globl _entry_253
_entry_253:
	.short 65144
/* end data */

.data
.balign 4
.globl _entry_254
_entry_254:
	.int 2164130554
/* end data */

.data
.balign 8
.globl _entry_255
_entry_255:
	.quad -81985529222004481
/* end data */

.data
.balign 16
.globl _entry_256
_entry_256:
	.int 1065353472
/* end data */

.data
.balign 32
.globl _entry_257
_entry_257:
	.quad 4607182418800017665
/* end data */

.bss
.balign 64
.globl _entry_258
_entry_258:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_259
_entry_259:
	.ascii "catalog-0259"
/* end data */

.data
.balign 64
.globl _entry_260
_entry_260:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_261
_entry_261:
	.byte 204
/* end data */

.data
.balign 2
.globl _entry_262
_entry_262:
	.short 1921
/* end data */

.data
.balign 4
.globl _entry_263
_entry_263:
	.int 2164720405
/* end data */

.data
.balign 8
.globl _entry_264
_entry_264:
	.quad -81985529222004472
/* end data */

.data
.balign 16
.globl _entry_265
_entry_265:
	.int 1065353481
/* end data */

.data
.balign 32
.globl _entry_266
_entry_266:
	.quad 4607182418800017674
/* end data */

.bss
.balign 64
.globl _entry_267
_entry_267:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_268
_entry_268:
	.ascii "catalog-0268"
/* end data */

.data
.balign 64
.globl _entry_269
_entry_269:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_270
_entry_270:
	.byte 25
/* end data */

.data
.balign 2
.globl _entry_271
_entry_271:
	.short 4234
/* end data */

.data
.balign 4
.globl _entry_272
_entry_272:
	.int 2165310256
/* end data */

.data
.balign 8
.globl _entry_273
_entry_273:
	.quad -81985529222004463
/* end data */

.data
.balign 16
.globl _entry_274
_entry_274:
	.int 1065353490
/* end data */

.data
.balign 32
.globl _entry_275
_entry_275:
	.quad 4607182418800017683
/* end data */

.bss
.balign 64
.globl _entry_276
_entry_276:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_277
_entry_277:
	.ascii "catalog-0277"
/* end data */

.data
.balign 64
.globl _entry_278
_entry_278:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_279
_entry_279:
	.byte 102
/* end data */

.data
.balign 2
.globl _entry_280
_entry_280:
	.short 6547
/* end data */

.data
.balign 4
.globl _entry_281
_entry_281:
	.int 2165900107
/* end data */

.data
.balign 8
.globl _entry_282
_entry_282:
	.quad -81985529222004454
/* end data */

.data
.balign 16
.globl _entry_283
_entry_283:
	.int 1065353499
/* end data */

.data
.balign 32
.globl _entry_284
_entry_284:
	.quad 4607182418800017692
/* end data */

.bss
.balign 64
.globl _entry_285
_entry_285:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_286
_entry_286:
	.ascii "catalog-0286"
/* end data */

.data
.balign 64
.globl _entry_287
_entry_287:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_288
_entry_288:
	.byte 179
/* end data */

.data
.balign 2
.globl _entry_289
_entry_289:
	.short 8860
/* end data */

.data
.balign 4
.globl _entry_290
_entry_290:
	.int 2166489958
/* end data */

.data
.balign 8
.globl _entry_291
_entry_291:
	.quad -81985529222004445
/* end data */

.data
.balign 16
.globl _entry_292
_entry_292:
	.int 1065353508
/* end data */

.data
.balign 32
.globl _entry_293
_entry_293:
	.quad 4607182418800017701
/* end data */

.bss
.balign 64
.globl _entry_294
_entry_294:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_295
_entry_295:
	.ascii "catalog-0295"
/* end data */

.data
.balign 64
.globl _entry_296
_entry_296:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_297
_entry_297:
	.byte 0
/* end data */

.data
.balign 2
.globl _entry_298
_entry_298:
	.short 11173
/* end data */

.data
.balign 4
.globl _entry_299
_entry_299:
	.int 2167079809
/* end data */

.data
.balign 8
.globl _entry_300
_entry_300:
	.quad -81985529222004436
/* end data */

.data
.balign 16
.globl _entry_301
_entry_301:
	.int 1065353517
/* end data */

.data
.balign 32
.globl _entry_302
_entry_302:
	.quad 4607182418800017710
/* end data */

.bss
.balign 64
.globl _entry_303
_entry_303:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_304
_entry_304:
	.ascii "catalog-0304"
/* end data */

.data
.balign 64
.globl _entry_305
_entry_305:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_306
_entry_306:
	.byte 77
/* end data */

.data
.balign 2
.globl _entry_307
_entry_307:
	.short 13486
/* end data */

.data
.balign 4
.globl _entry_308
_entry_308:
	.int 2167669660
/* end data */

.data
.balign 8
.globl _entry_309
_entry_309:
	.quad -81985529222004427
/* end data */

.data
.balign 16
.globl _entry_310
_entry_310:
	.int 1065353526
/* end data */

.data
.balign 32
.globl _entry_311
_entry_311:
	.quad 4607182418800017719
/* end data */

.bss
.balign 64
.globl _entry_312
_entry_312:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_313
_entry_313:
	.ascii "catalog-0313"
/* end data */

.data
.balign 64
.globl _entry_314
_entry_314:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_315
_entry_315:
	.byte 154
/* end data */

.data
.balign 2
.globl _entry_316
_entry_316:
	.short 15799
/* end data */

.data
.balign 4
.globl _entry_317
_entry_317:
	.int 2168259511
/* end data */

.data
.balign 8
.globl _entry_318
_entry_318:
	.quad -81985529222004418
/* end data */

.data
.balign 16
.globl _entry_319
_entry_319:
	.int 1065353535
/* end data */

.data
.balign 32
.globl _entry_320
_entry_320:
	.quad 4607182418800017728
/* end data */

.bss
.balign 64
.globl _entry_321
_entry_321:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_322
_entry_322:
	.ascii "catalog-0322"
/* end data */

.data
.balign 64
.globl _entry_323
_entry_323:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_324
_entry_324:
	.byte 231
/* end data */

.data
.balign 2
.globl _entry_325
_entry_325:
	.short 18112
/* end data */

.data
.balign 4
.globl _entry_326
_entry_326:
	.int 2168849362
/* end data */

.data
.balign 8
.globl _entry_327
_entry_327:
	.quad -81985529222004409
/* end data */

.data
.balign 16
.globl _entry_328
_entry_328:
	.int 1065353544
/* end data */

.data
.balign 32
.globl _entry_329
_entry_329:
	.quad 4607182418800017737
/* end data */

.bss
.balign 64
.globl _entry_330
_entry_330:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_331
_entry_331:
	.ascii "catalog-0331"
/* end data */

.data
.balign 64
.globl _entry_332
_entry_332:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_333
_entry_333:
	.byte 52
/* end data */

.data
.balign 2
.globl _entry_334
_entry_334:
	.short 20425
/* end data */

.data
.balign 4
.globl _entry_335
_entry_335:
	.int 2169439213
/* end data */

.data
.balign 8
.globl _entry_336
_entry_336:
	.quad -81985529222004400
/* end data */

.data
.balign 16
.globl _entry_337
_entry_337:
	.int 1065353553
/* end data */

.data
.balign 32
.globl _entry_338
_entry_338:
	.quad 4607182418800017746
/* end data */

.bss
.balign 64
.globl _entry_339
_entry_339:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_340
_entry_340:
	.ascii "catalog-0340"
/* end data */

.data
.balign 64
.globl _entry_341
_entry_341:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_342
_entry_342:
	.byte 129
/* end data */

.data
.balign 2
.globl _entry_343
_entry_343:
	.short 22738
/* end data */

.data
.balign 4
.globl _entry_344
_entry_344:
	.int 2170029064
/* end data */

.data
.balign 8
.globl _entry_345
_entry_345:
	.quad -81985529222004391
/* end data */

.data
.balign 16
.globl _entry_346
_entry_346:
	.int 1065353562
/* end data */

.data
.balign 32
.globl _entry_347
_entry_347:
	.quad 4607182418800017755
/* end data */

.bss
.balign 64
.globl _entry_348
_entry_348:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_349
_entry_349:
	.ascii "catalog-0349"
/* end data */

.data
.balign 64
.globl _entry_350
_entry_350:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_351
_entry_351:
	.byte 206
/* end data */

.data
.balign 2
.globl _entry_352
_entry_352:
	.short 25051
/* end data */

.data
.balign 4
.globl _entry_353
_entry_353:
	.int 2170618915
/* end data */

.data
.balign 8
.globl _entry_354
_entry_354:
	.quad -81985529222004382
/* end data */

.data
.balign 16
.globl _entry_355
_entry_355:
	.int 1065353571
/* end data */

.data
.balign 32
.globl _entry_356
_entry_356:
	.quad 4607182418800017764
/* end data */

.bss
.balign 64
.globl _entry_357
_entry_357:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_358
_entry_358:
	.ascii "catalog-0358"
/* end data */

.data
.balign 64
.globl _entry_359
_entry_359:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_360
_entry_360:
	.byte 27
/* end data */

.data
.balign 2
.globl _entry_361
_entry_361:
	.short 27364
/* end data */

.data
.balign 4
.globl _entry_362
_entry_362:
	.int 2171208766
/* end data */

.data
.balign 8
.globl _entry_363
_entry_363:
	.quad -81985529222004373
/* end data */

.data
.balign 16
.globl _entry_364
_entry_364:
	.int 1065353580
/* end data */

.data
.balign 32
.globl _entry_365
_entry_365:
	.quad 4607182418800017773
/* end data */

.bss
.balign 64
.globl _entry_366
_entry_366:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_367
_entry_367:
	.ascii "catalog-0367"
/* end data */

.data
.balign 64
.globl _entry_368
_entry_368:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_369
_entry_369:
	.byte 104
/* end data */

.data
.balign 2
.globl _entry_370
_entry_370:
	.short 29677
/* end data */

.data
.balign 4
.globl _entry_371
_entry_371:
	.int 2171798617
/* end data */

.data
.balign 8
.globl _entry_372
_entry_372:
	.quad -81985529222004364
/* end data */

.data
.balign 16
.globl _entry_373
_entry_373:
	.int 1065353589
/* end data */

.data
.balign 32
.globl _entry_374
_entry_374:
	.quad 4607182418800017782
/* end data */

.bss
.balign 64
.globl _entry_375
_entry_375:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_376
_entry_376:
	.ascii "catalog-0376"
/* end data */

.data
.balign 64
.globl _entry_377
_entry_377:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_378
_entry_378:
	.byte 181
/* end data */

.data
.balign 2
.globl _entry_379
_entry_379:
	.short 31990
/* end data */

.data
.balign 4
.globl _entry_380
_entry_380:
	.int 2172388468
/* end data */

.data
.balign 8
.globl _entry_381
_entry_381:
	.quad -81985529222004355
/* end data */

.data
.balign 16
.globl _entry_382
_entry_382:
	.int 1065353598
/* end data */

.data
.balign 32
.globl _entry_383
_entry_383:
	.quad 4607182418800017791
/* end data */

.bss
.balign 64
.globl _entry_384
_entry_384:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_385
_entry_385:
	.ascii "catalog-0385"
/* end data */

.data
.balign 64
.globl _entry_386
_entry_386:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_387
_entry_387:
	.byte 2
/* end data */

.data
.balign 2
.globl _entry_388
_entry_388:
	.short 34303
/* end data */

.data
.balign 4
.globl _entry_389
_entry_389:
	.int 2172978319
/* end data */

.data
.balign 8
.globl _entry_390
_entry_390:
	.quad -81985529222004346
/* end data */

.data
.balign 16
.globl _entry_391
_entry_391:
	.int 1065353607
/* end data */

.data
.balign 32
.globl _entry_392
_entry_392:
	.quad 4607182418800017800
/* end data */

.bss
.balign 64
.globl _entry_393
_entry_393:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_394
_entry_394:
	.ascii "catalog-0394"
/* end data */

.data
.balign 64
.globl _entry_395
_entry_395:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_396
_entry_396:
	.byte 79
/* end data */

.data
.balign 2
.globl _entry_397
_entry_397:
	.short 36616
/* end data */

.data
.balign 4
.globl _entry_398
_entry_398:
	.int 2173568170
/* end data */

.data
.balign 8
.globl _entry_399
_entry_399:
	.quad -81985529222004337
/* end data */

.data
.balign 16
.globl _entry_400
_entry_400:
	.int 1065353616
/* end data */

.data
.balign 32
.globl _entry_401
_entry_401:
	.quad 4607182418800017809
/* end data */

.bss
.balign 64
.globl _entry_402
_entry_402:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_403
_entry_403:
	.ascii "catalog-0403"
/* end data */

.data
.balign 64
.globl _entry_404
_entry_404:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_405
_entry_405:
	.byte 156
/* end data */

.data
.balign 2
.globl _entry_406
_entry_406:
	.short 38929
/* end data */

.data
.balign 4
.globl _entry_407
_entry_407:
	.int 2174158021
/* end data */

.data
.balign 8
.globl _entry_408
_entry_408:
	.quad -81985529222004328
/* end data */

.data
.balign 16
.globl _entry_409
_entry_409:
	.int 1065353625
/* end data */

.data
.balign 32
.globl _entry_410
_entry_410:
	.quad 4607182418800017818
/* end data */

.bss
.balign 64
.globl _entry_411
_entry_411:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_412
_entry_412:
	.ascii "catalog-0412"
/* end data */

.data
.balign 64
.globl _entry_413
_entry_413:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_414
_entry_414:
	.byte 233
/* end data */

.data
.balign 2
.globl _entry_415
_entry_415:
	.short 41242
/* end data */

.data
.balign 4
.globl _entry_416
_entry_416:
	.int 2174747872
/* end data */

.data
.balign 8
.globl _entry_417
_entry_417:
	.quad -81985529222004319
/* end data */

.data
.balign 16
.globl _entry_418
_entry_418:
	.int 1065353634
/* end data */

.data
.balign 32
.globl _entry_419
_entry_419:
	.quad 4607182418800017827
/* end data */

.bss
.balign 64
.globl _entry_420
_entry_420:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_421
_entry_421:
	.ascii "catalog-0421"
/* end data */

.data
.balign 64
.globl _entry_422
_entry_422:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_423
_entry_423:
	.byte 54
/* end data */

.data
.balign 2
.globl _entry_424
_entry_424:
	.short 43555
/* end data */

.data
.balign 4
.globl _entry_425
_entry_425:
	.int 2175337723
/* end data */

.data
.balign 8
.globl _entry_426
_entry_426:
	.quad -81985529222004310
/* end data */

.data
.balign 16
.globl _entry_427
_entry_427:
	.int 1065353643
/* end data */

.data
.balign 32
.globl _entry_428
_entry_428:
	.quad 4607182418800017836
/* end data */

.bss
.balign 64
.globl _entry_429
_entry_429:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_430
_entry_430:
	.ascii "catalog-0430"
/* end data */

.data
.balign 64
.globl _entry_431
_entry_431:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_432
_entry_432:
	.byte 131
/* end data */

.data
.balign 2
.globl _entry_433
_entry_433:
	.short 45868
/* end data */

.data
.balign 4
.globl _entry_434
_entry_434:
	.int 2175927574
/* end data */

.data
.balign 8
.globl _entry_435
_entry_435:
	.quad -81985529222004301
/* end data */

.data
.balign 16
.globl _entry_436
_entry_436:
	.int 1065353652
/* end data */

.data
.balign 32
.globl _entry_437
_entry_437:
	.quad 4607182418800017845
/* end data */

.bss
.balign 64
.globl _entry_438
_entry_438:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_439
_entry_439:
	.ascii "catalog-0439"
/* end data */

.data
.balign 64
.globl _entry_440
_entry_440:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_441
_entry_441:
	.byte 208
/* end data */

.data
.balign 2
.globl _entry_442
_entry_442:
	.short 48181
/* end data */

.data
.balign 4
.globl _entry_443
_entry_443:
	.int 2176517425
/* end data */

.data
.balign 8
.globl _entry_444
_entry_444:
	.quad -81985529222004292
/* end data */

.data
.balign 16
.globl _entry_445
_entry_445:
	.int 1065353661
/* end data */

.data
.balign 32
.globl _entry_446
_entry_446:
	.quad 4607182418800017854
/* end data */

.bss
.balign 64
.globl _entry_447
_entry_447:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_448
_entry_448:
	.ascii "catalog-0448"
/* end data */

.data
.balign 64
.globl _entry_449
_entry_449:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_450
_entry_450:
	.byte 29
/* end data */

.data
.balign 2
.globl _entry_451
_entry_451:
	.short 50494
/* end data */

.data
.balign 4
.globl _entry_452
_entry_452:
	.int 2177107276
/* end data */

.data
.balign 8
.globl _entry_453
_entry_453:
	.quad -81985529222004283
/* end data */

.data
.balign 16
.globl _entry_454
_entry_454:
	.int 1065353670
/* end data */

.data
.balign 32
.globl _entry_455
_entry_455:
	.quad 4607182418800017863
/* end data */

.bss
.balign 64
.globl _entry_456
_entry_456:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_457
_entry_457:
	.ascii "catalog-0457"
/* end data */

.data
.balign 64
.globl _entry_458
_entry_458:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_459
_entry_459:
	.byte 106
/* end data */

.data
.balign 2
.globl _entry_460
_entry_460:
	.short 52807
/* end data */

.data
.balign 4
.globl _entry_461
_entry_461:
	.int 2177697127
/* end data */

.data
.balign 8
.globl _entry_462
_entry_462:
	.quad -81985529222004274
/* end data */

.data
.balign 16
.globl _entry_463
_entry_463:
	.int 1065353679
/* end data */

.data
.balign 32
.globl _entry_464
_entry_464:
	.quad 4607182418800017872
/* end data */

.bss
.balign 64
.globl _entry_465
_entry_465:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_466
_entry_466:
	.ascii "catalog-0466"
/* end data */

.data
.balign 64
.globl _entry_467
_entry_467:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_468
_entry_468:
	.byte 183
/* end data */

.data
.balign 2
.globl _entry_469
_entry_469:
	.short 55120
/* end data */

.data
.balign 4
.globl _entry_470
_entry_470:
	.int 2178286978
/* end data */

.data
.balign 8
.globl _entry_471
_entry_471:
	.quad -81985529222004265
/* end data */

.data
.balign 16
.globl _entry_472
_entry_472:
	.int 1065353688
/* end data */

.data
.balign 32
.globl _entry_473
_entry_473:
	.quad 4607182418800017881
/* end data */

.bss
.balign 64
.globl _entry_474
_entry_474:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_475
_entry_475:
	.ascii "catalog-0475"
/* end data */

.data
.balign 64
.globl _entry_476
_entry_476:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_477
_entry_477:
	.byte 4
/* end data */

.data
.balign 2
.globl _entry_478
_entry_478:
	.short 57433
/* end data */

.data
.balign 4
.globl _entry_479
_entry_479:
	.int 2178876829
/* end data */

.data
.balign 8
.globl _entry_480
_entry_480:
	.quad -81985529222004256
/* end data */

.data
.balign 16
.globl _entry_481
_entry_481:
	.int 1065353697
/* end data */

.data
.balign 32
.globl _entry_482
_entry_482:
	.quad 4607182418800017890
/* end data */

.bss
.balign 64
.globl _entry_483
_entry_483:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_484
_entry_484:
	.ascii "catalog-0484"
/* end data */

.data
.balign 64
.globl _entry_485
_entry_485:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_486
_entry_486:
	.byte 81
/* end data */

.data
.balign 2
.globl _entry_487
_entry_487:
	.short 59746
/* end data */

.data
.balign 4
.globl _entry_488
_entry_488:
	.int 2179466680
/* end data */

.data
.balign 8
.globl _entry_489
_entry_489:
	.quad -81985529222004247
/* end data */

.data
.balign 16
.globl _entry_490
_entry_490:
	.int 1065353706
/* end data */

.data
.balign 32
.globl _entry_491
_entry_491:
	.quad 4607182418800017899
/* end data */

.bss
.balign 64
.globl _entry_492
_entry_492:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_493
_entry_493:
	.ascii "catalog-0493"
/* end data */

.data
.balign 64
.globl _entry_494
_entry_494:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_495
_entry_495:
	.byte 158
/* end data */

.data
.balign 2
.globl _entry_496
_entry_496:
	.short 62059
/* end data */

.data
.balign 4
.globl _entry_497
_entry_497:
	.int 2180056531
/* end data */

.data
.balign 8
.globl _entry_498
_entry_498:
	.quad -81985529222004238
/* end data */

.data
.balign 16
.globl _entry_499
_entry_499:
	.int 1065353715
/* end data */

.data
.balign 32
.globl _entry_500
_entry_500:
	.quad 4607182418800017908
/* end data */

.bss
.balign 64
.globl _entry_501
_entry_501:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_502
_entry_502:
	.ascii "catalog-0502"
/* end data */

.data
.balign 64
.globl _entry_503
_entry_503:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_504
_entry_504:
	.byte 235
/* end data */

.data
.balign 2
.globl _entry_505
_entry_505:
	.short 64372
/* end data */

.data
.balign 4
.globl _entry_506
_entry_506:
	.int 2180646382
/* end data */

.data
.balign 8
.globl _entry_507
_entry_507:
	.quad -81985529222004229
/* end data */

.data
.balign 16
.globl _entry_508
_entry_508:
	.int 1065353724
/* end data */

.data
.balign 32
.globl _entry_509
_entry_509:
	.quad 4607182418800017917
/* end data */

.bss
.balign 64
.globl _entry_510
_entry_510:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_511
_entry_511:
	.ascii "catalog-0511"
/* end data */

.data
.balign 64
.globl _entry_512
_entry_512:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_513
_entry_513:
	.byte 56
/* end data */

.data
.balign 2
.globl _entry_514
_entry_514:
	.short 1149
/* end data */

.data
.balign 4
.globl _entry_515
_entry_515:
	.int 2181236233
/* end data */

.data
.balign 8
.globl _entry_516
_entry_516:
	.quad -81985529222004220
/* end data */

.data
.balign 16
.globl _entry_517
_entry_517:
	.int 1065353733
/* end data */

.data
.balign 32
.globl _entry_518
_entry_518:
	.quad 4607182418800017926
/* end data */

.bss
.balign 64
.globl _entry_519
_entry_519:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_520
_entry_520:
	.ascii "catalog-0520"
/* end data */

.data
.balign 64
.globl _entry_521
_entry_521:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_522
_entry_522:
	.byte 133
/* end data */

.data
.balign 2
.globl _entry_523
_entry_523:
	.short 3462
/* end data */

.data
.balign 4
.globl _entry_524
_entry_524:
	.int 2181826084
/* end data */

.data
.balign 8
.globl _entry_525
_entry_525:
	.quad -81985529222004211
/* end data */

.data
.balign 16
.globl _entry_526
_entry_526:
	.int 1065353742
/* end data */

.data
.balign 32
.globl _entry_527
_entry_527:
	.quad 4607182418800017935
/* end data */

.bss
.balign 64
.globl _entry_528
_entry_528:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_529
_entry_529:
	.ascii "catalog-0529"
/* end data */

.data
.balign 64
.globl _entry_530
_entry_530:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_531
_entry_531:
	.byte 210
/* end data */

.data
.balign 2
.globl _entry_532
_entry_532:
	.short 5775
/* end data */

.data
.balign 4
.globl _entry_533
_entry_533:
	.int 2182415935
/* end data */

.data
.balign 8
.globl _entry_534
_entry_534:
	.quad -81985529222004202
/* end data */

.data
.balign 16
.globl _entry_535
_entry_535:
	.int 1065353751
/* end data */

.data
.balign 32
.globl _entry_536
_entry_536:
	.quad 4607182418800017944
/* end data */

.bss
.balign 64
.globl _entry_537
_entry_537:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_538
_entry_538:
	.ascii "catalog-0538"
/* end data */

.data
.balign 64
.globl _entry_539
_entry_539:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_540
_entry_540:
	.byte 31
/* end data */

.data
.balign 2
.globl _entry_541
_entry_541:
	.short 8088
/* end data */

.data
.balign 4
.globl _entry_542
_entry_542:
	.int 2183005786
/* end data */

.data
.balign 8
.globl _entry_543
_entry_543:
	.quad -81985529222004193
/* end data */

.data
.balign 16
.globl _entry_544
_entry_544:
	.int 1065353760
/* end data */

.data
.balign 32
.globl _entry_545
_entry_545:
	.quad 4607182418800017953
/* end data */

.bss
.balign 64
.globl _entry_546
_entry_546:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_547
_entry_547:
	.ascii "catalog-0547"
/* end data */

.data
.balign 64
.globl _entry_548
_entry_548:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_549
_entry_549:
	.byte 108
/* end data */

.data
.balign 2
.globl _entry_550
_entry_550:
	.short 10401
/* end data */

.data
.balign 4
.globl _entry_551
_entry_551:
	.int 2183595637
/* end data */

.data
.balign 8
.globl _entry_552
_entry_552:
	.quad -81985529222004184
/* end data */

.data
.balign 16
.globl _entry_553
_entry_553:
	.int 1065353769
/* end data */

.data
.balign 32
.globl _entry_554
_entry_554:
	.quad 4607182418800017962
/* end data */

.bss
.balign 64
.globl _entry_555
_entry_555:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_556
_entry_556:
	.ascii "catalog-0556"
/* end data */

.data
.balign 64
.globl _entry_557
_entry_557:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_558
_entry_558:
	.byte 185
/* end data */

.data
.balign 2
.globl _entry_559
_entry_559:
	.short 12714
/* end data */

.data
.balign 4
.globl _entry_560
_entry_560:
	.int 2184185488
/* end data */

.data
.balign 8
.globl _entry_561
_entry_561:
	.quad -81985529222004175
/* end data */

.data
.balign 16
.globl _entry_562
_entry_562:
	.int 1065353778
/* end data */

.data
.balign 32
.globl _entry_563
_entry_563:
	.quad 4607182418800017971
/* end data */

.bss
.balign 64
.globl _entry_564
_entry_564:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_565
_entry_565:
	.ascii "catalog-0565"
/* end data */

.data
.balign 64
.globl _entry_566
_entry_566:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_567
_entry_567:
	.byte 6
/* end data */

.data
.balign 2
.globl _entry_568
_entry_568:
	.short 15027
/* end data */

.data
.balign 4
.globl _entry_569
_entry_569:
	.int 2184775339
/* end data */

.data
.balign 8
.globl _entry_570
_entry_570:
	.quad -81985529222004166
/* end data */

.data
.balign 16
.globl _entry_571
_entry_571:
	.int 1065353787
/* end data */

.data
.balign 32
.globl _entry_572
_entry_572:
	.quad 4607182418800017980
/* end data */

.bss
.balign 64
.globl _entry_573
_entry_573:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_574
_entry_574:
	.ascii "catalog-0574"
/* end data */

.data
.balign 64
.globl _entry_575
_entry_575:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_576
_entry_576:
	.byte 83
/* end data */

.data
.balign 2
.globl _entry_577
_entry_577:
	.short 17340
/* end data */

.data
.balign 4
.globl _entry_578
_entry_578:
	.int 2185365190
/* end data */

.data
.balign 8
.globl _entry_579
_entry_579:
	.quad -81985529222004157
/* end data */

.data
.balign 16
.globl _entry_580
_entry_580:
	.int 1065353796
/* end data */

.data
.balign 32
.globl _entry_581
_entry_581:
	.quad 4607182418800017989
/* end data */

.bss
.balign 64
.globl _entry_582
_entry_582:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_583
_entry_583:
	.ascii "catalog-0583"
/* end data */

.data
.balign 64
.globl _entry_584
_entry_584:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_585
_entry_585:
	.byte 160
/* end data */

.data
.balign 2
.globl _entry_586
_entry_586:
	.short 19653
/* end data */

.data
.balign 4
.globl _entry_587
_entry_587:
	.int 2185955041
/* end data */

.data
.balign 8
.globl _entry_588
_entry_588:
	.quad -81985529222004148
/* end data */

.data
.balign 16
.globl _entry_589
_entry_589:
	.int 1065353805
/* end data */

.data
.balign 32
.globl _entry_590
_entry_590:
	.quad 4607182418800017998
/* end data */

.bss
.balign 64
.globl _entry_591
_entry_591:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_592
_entry_592:
	.ascii "catalog-0592"
/* end data */

.data
.balign 64
.globl _entry_593
_entry_593:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_594
_entry_594:
	.byte 237
/* end data */

.data
.balign 2
.globl _entry_595
_entry_595:
	.short 21966
/* end data */

.data
.balign 4
.globl _entry_596
_entry_596:
	.int 2186544892
/* end data */

.data
.balign 8
.globl _entry_597
_entry_597:
	.quad -81985529222004139
/* end data */

.data
.balign 16
.globl _entry_598
_entry_598:
	.int 1065353814
/* end data */

.data
.balign 32
.globl _entry_599
_entry_599:
	.quad 4607182418800018007
/* end data */

.bss
.balign 64
.globl _entry_600
_entry_600:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_601
_entry_601:
	.ascii "catalog-0601"
/* end data */

.data
.balign 64
.globl _entry_602
_entry_602:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_603
_entry_603:
	.byte 58
/* end data */

.data
.balign 2
.globl _entry_604
_entry_604:
	.short 24279
/* end data */

.data
.balign 4
.globl _entry_605
_entry_605:
	.int 2187134743
/* end data */

.data
.balign 8
.globl _entry_606
_entry_606:
	.quad -81985529222004130
/* end data */

.data
.balign 16
.globl _entry_607
_entry_607:
	.int 1065353823
/* end data */

.data
.balign 32
.globl _entry_608
_entry_608:
	.quad 4607182418800018016
/* end data */

.bss
.balign 64
.globl _entry_609
_entry_609:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_610
_entry_610:
	.ascii "catalog-0610"
/* end data */

.data
.balign 64
.globl _entry_611
_entry_611:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_612
_entry_612:
	.byte 135
/* end data */

.data
.balign 2
.globl _entry_613
_entry_613:
	.short 26592
/* end data */

.data
.balign 4
.globl _entry_614
_entry_614:
	.int 2187724594
/* end data */

.data
.balign 8
.globl _entry_615
_entry_615:
	.quad -81985529222004121
/* end data */

.data
.balign 16
.globl _entry_616
_entry_616:
	.int 1065353832
/* end data */

.data
.balign 32
.globl _entry_617
_entry_617:
	.quad 4607182418800018025
/* end data */

.bss
.balign 64
.globl _entry_618
_entry_618:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_619
_entry_619:
	.ascii "catalog-0619"
/* end data */

.data
.balign 64
.globl _entry_620
_entry_620:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_621
_entry_621:
	.byte 212
/* end data */

.data
.balign 2
.globl _entry_622
_entry_622:
	.short 28905
/* end data */

.data
.balign 4
.globl _entry_623
_entry_623:
	.int 2188314445
/* end data */

.data
.balign 8
.globl _entry_624
_entry_624:
	.quad -81985529222004112
/* end data */

.data
.balign 16
.globl _entry_625
_entry_625:
	.int 1065353841
/* end data */

.data
.balign 32
.globl _entry_626
_entry_626:
	.quad 4607182418800018034
/* end data */

.bss
.balign 64
.globl _entry_627
_entry_627:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_628
_entry_628:
	.ascii "catalog-0628"
/* end data */

.data
.balign 64
.globl _entry_629
_entry_629:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_630
_entry_630:
	.byte 33
/* end data */

.data
.balign 2
.globl _entry_631
_entry_631:
	.short 31218
/* end data */

.data
.balign 4
.globl _entry_632
_entry_632:
	.int 2188904296
/* end data */

.data
.balign 8
.globl _entry_633
_entry_633:
	.quad -81985529222004103
/* end data */

.data
.balign 16
.globl _entry_634
_entry_634:
	.int 1065353850
/* end data */

.data
.balign 32
.globl _entry_635
_entry_635:
	.quad 4607182418800018043
/* end data */

.bss
.balign 64
.globl _entry_636
_entry_636:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_637
_entry_637:
	.ascii "catalog-0637"
/* end data */

.data
.balign 64
.globl _entry_638
_entry_638:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_639
_entry_639:
	.byte 110
/* end data */

.data
.balign 2
.globl _entry_640
_entry_640:
	.short 33531
/* end data */

.data
.balign 4
.globl _entry_641
_entry_641:
	.int 2189494147
/* end data */

.data
.balign 8
.globl _entry_642
_entry_642:
	.quad -81985529222004094
/* end data */

.data
.balign 16
.globl _entry_643
_entry_643:
	.int 1065353859
/* end data */

.data
.balign 32
.globl _entry_644
_entry_644:
	.quad 4607182418800018052
/* end data */

.bss
.balign 64
.globl _entry_645
_entry_645:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_646
_entry_646:
	.ascii "catalog-0646"
/* end data */

.data
.balign 64
.globl _entry_647
_entry_647:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_648
_entry_648:
	.byte 187
/* end data */

.data
.balign 2
.globl _entry_649
_entry_649:
	.short 35844
/* end data */

.data
.balign 4
.globl _entry_650
_entry_650:
	.int 2190083998
/* end data */

.data
.balign 8
.globl _entry_651
_entry_651:
	.quad -81985529222004085
/* end data */

.data
.balign 16
.globl _entry_652
_entry_652:
	.int 1065353868
/* end data */

.data
.balign 32
.globl _entry_653
_entry_653:
	.quad 4607182418800018061
/* end data */

.bss
.balign 64
.globl _entry_654
_entry_654:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_655
_entry_655:
	.ascii "catalog-0655"
/* end data */

.data
.balign 64
.globl _entry_656
_entry_656:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_657
_entry_657:
	.byte 8
/* end data */

.data
.balign 2
.globl _entry_658
_entry_658:
	.short 38157
/* end data */

.data
.balign 4
.globl _entry_659
_entry_659:
	.int 2190673849
/* end data */

.data
.balign 8
.globl _entry_660
_entry_660:
	.quad -81985529222004076
/* end data */

.data
.balign 16
.globl _entry_661
_entry_661:
	.int 1065353877
/* end data */

.data
.balign 32
.globl _entry_662
_entry_662:
	.quad 4607182418800018070
/* end data */

.bss
.balign 64
.globl _entry_663
_entry_663:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_664
_entry_664:
	.ascii "catalog-0664"
/* end data */

.data
.balign 64
.globl _entry_665
_entry_665:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_666
_entry_666:
	.byte 85
/* end data */

.data
.balign 2
.globl _entry_667
_entry_667:
	.short 40470
/* end data */

.data
.balign 4
.globl _entry_668
_entry_668:
	.int 2191263700
/* end data */

.data
.balign 8
.globl _entry_669
_entry_669:
	.quad -81985529222004067
/* end data */

.data
.balign 16
.globl _entry_670
_entry_670:
	.int 1065353886
/* end data */

.data
.balign 32
.globl _entry_671
_entry_671:
	.quad 4607182418800018079
/* end data */

.bss
.balign 64
.globl _entry_672
_entry_672:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_673
_entry_673:
	.ascii "catalog-0673"
/* end data */

.data
.balign 64
.globl _entry_674
_entry_674:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_675
_entry_675:
	.byte 162
/* end data */

.data
.balign 2
.globl _entry_676
_entry_676:
	.short 42783
/* end data */

.data
.balign 4
.globl _entry_677
_entry_677:
	.int 2191853551
/* end data */

.data
.balign 8
.globl _entry_678
_entry_678:
	.quad -81985529222004058
/* end data */

.data
.balign 16
.globl _entry_679
_entry_679:
	.int 1065353895
/* end data */

.data
.balign 32
.globl _entry_680
_entry_680:
	.quad 4607182418800018088
/* end data */

.bss
.balign 64
.globl _entry_681
_entry_681:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_682
_entry_682:
	.ascii "catalog-0682"
/* end data */

.data
.balign 64
.globl _entry_683
_entry_683:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_684
_entry_684:
	.byte 239
/* end data */

.data
.balign 2
.globl _entry_685
_entry_685:
	.short 45096
/* end data */

.data
.balign 4
.globl _entry_686
_entry_686:
	.int 2192443402
/* end data */

.data
.balign 8
.globl _entry_687
_entry_687:
	.quad -81985529222004049
/* end data */

.data
.balign 16
.globl _entry_688
_entry_688:
	.int 1065353904
/* end data */

.data
.balign 32
.globl _entry_689
_entry_689:
	.quad 4607182418800018097
/* end data */

.bss
.balign 64
.globl _entry_690
_entry_690:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_691
_entry_691:
	.ascii "catalog-0691"
/* end data */

.data
.balign 64
.globl _entry_692
_entry_692:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_693
_entry_693:
	.byte 60
/* end data */

.data
.balign 2
.globl _entry_694
_entry_694:
	.short 47409
/* end data */

.data
.balign 4
.globl _entry_695
_entry_695:
	.int 2193033253
/* end data */

.data
.balign 8
.globl _entry_696
_entry_696:
	.quad -81985529222004040
/* end data */

.data
.balign 16
.globl _entry_697
_entry_697:
	.int 1065353913
/* end data */

.data
.balign 32
.globl _entry_698
_entry_698:
	.quad 4607182418800018106
/* end data */

.bss
.balign 64
.globl _entry_699
_entry_699:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_700
_entry_700:
	.ascii "catalog-0700"
/* end data */

.data
.balign 64
.globl _entry_701
_entry_701:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_702
_entry_702:
	.byte 137
/* end data */

.data
.balign 2
.globl _entry_703
_entry_703:
	.short 49722
/* end data */

.data
.balign 4
.globl _entry_704
_entry_704:
	.int 2193623104
/* end data */

.data
.balign 8
.globl _entry_705
_entry_705:
	.quad -81985529222004031
/* end data */

.data
.balign 16
.globl _entry_706
_entry_706:
	.int 1065353922
/* end data */

.data
.balign 32
.globl _entry_707
_entry_707:
	.quad 4607182418800018115
/* end data */

.bss
.balign 64
.globl _entry_708
_entry_708:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_709
_entry_709:
	.ascii "catalog-0709"
/* end data */

.data
.balign 64
.globl _entry_710
_entry_710:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_711
_entry_711:
	.byte 214
/* end data */

.data
.balign 2
.globl _entry_712
_entry_712:
	.short 52035
/* end data */

.data
.balign 4
.globl _entry_713
_entry_713:
	.int 2194212955
/* end data */

.data
.balign 8
.globl _entry_714
_entry_714:
	.quad -81985529222004022
/* end data */

.data
.balign 16
.globl _entry_715
_entry_715:
	.int 1065353931
/* end data */

.data
.balign 32
.globl _entry_716
_entry_716:
	.quad 4607182418800018124
/* end data */

.bss
.balign 64
.globl _entry_717
_entry_717:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_718
_entry_718:
	.ascii "catalog-0718"
/* end data */

.data
.balign 64
.globl _entry_719
_entry_719:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_720
_entry_720:
	.byte 35
/* end data */

.data
.balign 2
.globl _entry_721
_entry_721:
	.short 54348
/* end data */

.data
.balign 4
.globl _entry_722
_entry_722:
	.int 2194802806
/* end data */

.data
.balign 8
.globl _entry_723
_entry_723:
	.quad -81985529222004013
/* end data */

.data
.balign 16
.globl _entry_724
_entry_724:
	.int 1065353940
/* end data */

.data
.balign 32
.globl _entry_725
_entry_725:
	.quad 4607182418800018133
/* end data */

.bss
.balign 64
.globl _entry_726
_entry_726:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_727
_entry_727:
	.ascii "catalog-0727"
/* end data */

.data
.balign 64
.globl _entry_728
_entry_728:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_729
_entry_729:
	.byte 112
/* end data */

.data
.balign 2
.globl _entry_730
_entry_730:
	.short 56661
/* end data */

.data
.balign 4
.globl _entry_731
_entry_731:
	.int 2195392657
/* end data */

.data
.balign 8
.globl _entry_732
_entry_732:
	.quad -81985529222004004
/* end data */

.data
.balign 16
.globl _entry_733
_entry_733:
	.int 1065353949
/* end data */

.data
.balign 32
.globl _entry_734
_entry_734:
	.quad 4607182418800018142
/* end data */

.bss
.balign 64
.globl _entry_735
_entry_735:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_736
_entry_736:
	.ascii "catalog-0736"
/* end data */

.data
.balign 64
.globl _entry_737
_entry_737:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_738
_entry_738:
	.byte 189
/* end data */

.data
.balign 2
.globl _entry_739
_entry_739:
	.short 58974
/* end data */

.data
.balign 4
.globl _entry_740
_entry_740:
	.int 2195982508
/* end data */

.data
.balign 8
.globl _entry_741
_entry_741:
	.quad -81985529222003995
/* end data */

.data
.balign 16
.globl _entry_742
_entry_742:
	.int 1065353958
/* end data */

.data
.balign 32
.globl _entry_743
_entry_743:
	.quad 4607182418800018151
/* end data */

.bss
.balign 64
.globl _entry_744
_entry_744:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_745
_entry_745:
	.ascii "catalog-0745"
/* end data */

.data
.balign 64
.globl _entry_746
_entry_746:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_747
_entry_747:
	.byte 10
/* end data */

.data
.balign 2
.globl _entry_748
_entry_748:
	.short 61287
/* end data */

.data
.balign 4
.globl _entry_749
_entry_749:
	.int 2196572359
/* end data */

.data
.balign 8
.globl _entry_750
_entry_750:
	.quad -81985529222003986
/* end data */

.data
.balign 16
.globl _entry_751
_entry_751:
	.int 1065353967
/* end data */

.data
.balign 32
.globl _entry_752
_entry_752:
	.quad 4607182418800018160
/* end data */

.bss
.balign 64
.globl _entry_753
_entry_753:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_754
_entry_754:
	.ascii "catalog-0754"
/* end data */

.data
.balign 64
.globl _entry_755
_entry_755:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_756
_entry_756:
	.byte 87
/* end data */

.data
.balign 2
.globl _entry_757
_entry_757:
	.short 63600
/* end data */

.data
.balign 4
.globl _entry_758
_entry_758:
	.int 2197162210
/* end data */

.data
.balign 8
.globl _entry_759
_entry_759:
	.quad -81985529222003977
/* end data */

.data
.balign 16
.globl _entry_760
_entry_760:
	.int 1065353976
/* end data */

.data
.balign 32
.globl _entry_761
_entry_761:
	.quad 4607182418800018169
/* end data */

.bss
.balign 64
.globl _entry_762
_entry_762:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_763
_entry_763:
	.ascii "catalog-0763"
/* end data */

.data
.balign 64
.globl _entry_764
_entry_764:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_765
_entry_765:
	.byte 164
/* end data */

.data
.balign 2
.globl _entry_766
_entry_766:
	.short 377
/* end data */

.data
.balign 4
.globl _entry_767
_entry_767:
	.int 2197752061
/* end data */

.data
.balign 8
.globl _entry_768
_entry_768:
	.quad -81985529222003968
/* end data */

.data
.balign 16
.globl _entry_769
_entry_769:
	.int 1065353985
/* end data */

.data
.balign 32
.globl _entry_770
_entry_770:
	.quad 4607182418800018178
/* end data */

.bss
.balign 64
.globl _entry_771
_entry_771:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_772
_entry_772:
	.ascii "catalog-0772"
/* end data */

.data
.balign 64
.globl _entry_773
_entry_773:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_774
_entry_774:
	.byte 241
/* end data */

.data
.balign 2
.globl _entry_775
_entry_775:
	.short 2690
/* end data */

.data
.balign 4
.globl _entry_776
_entry_776:
	.int 2198341912
/* end data */

.data
.balign 8
.globl _entry_777
_entry_777:
	.quad -81985529222003959
/* end data */

.data
.balign 16
.globl _entry_778
_entry_778:
	.int 1065353994
/* end data */

.data
.balign 32
.globl _entry_779
_entry_779:
	.quad 4607182418800018187
/* end data */

.bss
.balign 64
.globl _entry_780
_entry_780:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_781
_entry_781:
	.ascii "catalog-0781"
/* end data */

.data
.balign 64
.globl _entry_782
_entry_782:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_783
_entry_783:
	.byte 62
/* end data */

.data
.balign 2
.globl _entry_784
_entry_784:
	.short 5003
/* end data */

.data
.balign 4
.globl _entry_785
_entry_785:
	.int 2198931763
/* end data */

.data
.balign 8
.globl _entry_786
_entry_786:
	.quad -81985529222003950
/* end data */

.data
.balign 16
.globl _entry_787
_entry_787:
	.int 1065354003
/* end data */

.data
.balign 32
.globl _entry_788
_entry_788:
	.quad 4607182418800018196
/* end data */

.bss
.balign 64
.globl _entry_789
_entry_789:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_790
_entry_790:
	.ascii "catalog-0790"
/* end data */

.data
.balign 64
.globl _entry_791
_entry_791:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_792
_entry_792:
	.byte 139
/* end data */

.data
.balign 2
.globl _entry_793
_entry_793:
	.short 7316
/* end data */

.data
.balign 4
.globl _entry_794
_entry_794:
	.int 2199521614
/* end data */

.data
.balign 8
.globl _entry_795
_entry_795:
	.quad -81985529222003941
/* end data */

.data
.balign 16
.globl _entry_796
_entry_796:
	.int 1065354012
/* end data */

.data
.balign 32
.globl _entry_797
_entry_797:
	.quad 4607182418800018205
/* end data */

.bss
.balign 64
.globl _entry_798
_entry_798:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_799
_entry_799:
	.ascii "catalog-0799"
/* end data */

.data
.balign 64
.globl _entry_800
_entry_800:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_801
_entry_801:
	.byte 216
/* end data */

.data
.balign 2
.globl _entry_802
_entry_802:
	.short 9629
/* end data */

.data
.balign 4
.globl _entry_803
_entry_803:
	.int 2200111465
/* end data */

.data
.balign 8
.globl _entry_804
_entry_804:
	.quad -81985529222003932
/* end data */

.data
.balign 16
.globl _entry_805
_entry_805:
	.int 1065354021
/* end data */

.data
.balign 32
.globl _entry_806
_entry_806:
	.quad 4607182418800018214
/* end data */

.bss
.balign 64
.globl _entry_807
_entry_807:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_808
_entry_808:
	.ascii "catalog-0808"
/* end data */

.data
.balign 64
.globl _entry_809
_entry_809:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_810
_entry_810:
	.byte 37
/* end data */

.data
.balign 2
.globl _entry_811
_entry_811:
	.short 11942
/* end data */

.data
.balign 4
.globl _entry_812
_entry_812:
	.int 2200701316
/* end data */

.data
.balign 8
.globl _entry_813
_entry_813:
	.quad -81985529222003923
/* end data */

.data
.balign 16
.globl _entry_814
_entry_814:
	.int 1065354030
/* end data */

.data
.balign 32
.globl _entry_815
_entry_815:
	.quad 4607182418800018223
/* end data */

.bss
.balign 64
.globl _entry_816
_entry_816:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_817
_entry_817:
	.ascii "catalog-0817"
/* end data */

.data
.balign 64
.globl _entry_818
_entry_818:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_819
_entry_819:
	.byte 114
/* end data */

.data
.balign 2
.globl _entry_820
_entry_820:
	.short 14255
/* end data */

.data
.balign 4
.globl _entry_821
_entry_821:
	.int 2201291167
/* end data */

.data
.balign 8
.globl _entry_822
_entry_822:
	.quad -81985529222003914
/* end data */

.data
.balign 16
.globl _entry_823
_entry_823:
	.int 1065354039
/* end data */

.data
.balign 32
.globl _entry_824
_entry_824:
	.quad 4607182418800018232
/* end data */

.bss
.balign 64
.globl _entry_825
_entry_825:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_826
_entry_826:
	.ascii "catalog-0826"
/* end data */

.data
.balign 64
.globl _entry_827
_entry_827:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_828
_entry_828:
	.byte 191
/* end data */

.data
.balign 2
.globl _entry_829
_entry_829:
	.short 16568
/* end data */

.data
.balign 4
.globl _entry_830
_entry_830:
	.int 2201881018
/* end data */

.data
.balign 8
.globl _entry_831
_entry_831:
	.quad -81985529222003905
/* end data */

.data
.balign 16
.globl _entry_832
_entry_832:
	.int 1065354048
/* end data */

.data
.balign 32
.globl _entry_833
_entry_833:
	.quad 4607182418800018241
/* end data */

.bss
.balign 64
.globl _entry_834
_entry_834:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_835
_entry_835:
	.ascii "catalog-0835"
/* end data */

.data
.balign 64
.globl _entry_836
_entry_836:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_837
_entry_837:
	.byte 12
/* end data */

.data
.balign 2
.globl _entry_838
_entry_838:
	.short 18881
/* end data */

.data
.balign 4
.globl _entry_839
_entry_839:
	.int 2202470869
/* end data */

.data
.balign 8
.globl _entry_840
_entry_840:
	.quad -81985529222003896
/* end data */

.data
.balign 16
.globl _entry_841
_entry_841:
	.int 1065354057
/* end data */

.data
.balign 32
.globl _entry_842
_entry_842:
	.quad 4607182418800018250
/* end data */

.bss
.balign 64
.globl _entry_843
_entry_843:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_844
_entry_844:
	.ascii "catalog-0844"
/* end data */

.data
.balign 64
.globl _entry_845
_entry_845:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_846
_entry_846:
	.byte 89
/* end data */

.data
.balign 2
.globl _entry_847
_entry_847:
	.short 21194
/* end data */

.data
.balign 4
.globl _entry_848
_entry_848:
	.int 2203060720
/* end data */

.data
.balign 8
.globl _entry_849
_entry_849:
	.quad -81985529222003887
/* end data */

.data
.balign 16
.globl _entry_850
_entry_850:
	.int 1065354066
/* end data */

.data
.balign 32
.globl _entry_851
_entry_851:
	.quad 4607182418800018259
/* end data */

.bss
.balign 64
.globl _entry_852
_entry_852:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_853
_entry_853:
	.ascii "catalog-0853"
/* end data */

.data
.balign 64
.globl _entry_854
_entry_854:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_855
_entry_855:
	.byte 166
/* end data */

.data
.balign 2
.globl _entry_856
_entry_856:
	.short 23507
/* end data */

.data
.balign 4
.globl _entry_857
_entry_857:
	.int 2203650571
/* end data */

.data
.balign 8
.globl _entry_858
_entry_858:
	.quad -81985529222003878
/* end data */

.data
.balign 16
.globl _entry_859
_entry_859:
	.int 1065354075
/* end data */

.data
.balign 32
.globl _entry_860
_entry_860:
	.quad 4607182418800018268
/* end data */

.bss
.balign 64
.globl _entry_861
_entry_861:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_862
_entry_862:
	.ascii "catalog-0862"
/* end data */

.data
.balign 64
.globl _entry_863
_entry_863:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_864
_entry_864:
	.byte 243
/* end data */

.data
.balign 2
.globl _entry_865
_entry_865:
	.short 25820
/* end data */

.data
.balign 4
.globl _entry_866
_entry_866:
	.int 2204240422
/* end data */

.data
.balign 8
.globl _entry_867
_entry_867:
	.quad -81985529222003869
/* end data */

.data
.balign 16
.globl _entry_868
_entry_868:
	.int 1065354084
/* end data */

.data
.balign 32
.globl _entry_869
_entry_869:
	.quad 4607182418800018277
/* end data */

.bss
.balign 64
.globl _entry_870
_entry_870:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_871
_entry_871:
	.ascii "catalog-0871"
/* end data */

.data
.balign 64
.globl _entry_872
_entry_872:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_873
_entry_873:
	.byte 64
/* end data */

.data
.balign 2
.globl _entry_874
_entry_874:
	.short 28133
/* end data */

.data
.balign 4
.globl _entry_875
_entry_875:
	.int 2204830273
/* end data */

.data
.balign 8
.globl _entry_876
_entry_876:
	.quad -81985529222003860
/* end data */

.data
.balign 16
.globl _entry_877
_entry_877:
	.int 1065354093
/* end data */

.data
.balign 32
.globl _entry_878
_entry_878:
	.quad 4607182418800018286
/* end data */

.bss
.balign 64
.globl _entry_879
_entry_879:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_880
_entry_880:
	.ascii "catalog-0880"
/* end data */

.data
.balign 64
.globl _entry_881
_entry_881:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_882
_entry_882:
	.byte 141
/* end data */

.data
.balign 2
.globl _entry_883
_entry_883:
	.short 30446
/* end data */

.data
.balign 4
.globl _entry_884
_entry_884:
	.int 2205420124
/* end data */

.data
.balign 8
.globl _entry_885
_entry_885:
	.quad -81985529222003851
/* end data */

.data
.balign 16
.globl _entry_886
_entry_886:
	.int 1065354102
/* end data */

.data
.balign 32
.globl _entry_887
_entry_887:
	.quad 4607182418800018295
/* end data */

.bss
.balign 64
.globl _entry_888
_entry_888:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_889
_entry_889:
	.ascii "catalog-0889"
/* end data */

.data
.balign 64
.globl _entry_890
_entry_890:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_891
_entry_891:
	.byte 218
/* end data */

.data
.balign 2
.globl _entry_892
_entry_892:
	.short 32759
/* end data */

.data
.balign 4
.globl _entry_893
_entry_893:
	.int 2206009975
/* end data */

.data
.balign 8
.globl _entry_894
_entry_894:
	.quad -81985529222003842
/* end data */

.data
.balign 16
.globl _entry_895
_entry_895:
	.int 1065354111
/* end data */

.data
.balign 32
.globl _entry_896
_entry_896:
	.quad 4607182418800018304
/* end data */

.bss
.balign 64
.globl _entry_897
_entry_897:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_898
_entry_898:
	.ascii "catalog-0898"
/* end data */

.data
.balign 64
.globl _entry_899
_entry_899:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_900
_entry_900:
	.byte 39
/* end data */

.data
.balign 2
.globl _entry_901
_entry_901:
	.short 35072
/* end data */

.data
.balign 4
.globl _entry_902
_entry_902:
	.int 2206599826
/* end data */

.data
.balign 8
.globl _entry_903
_entry_903:
	.quad -81985529222003833
/* end data */

.data
.balign 16
.globl _entry_904
_entry_904:
	.int 1065354120
/* end data */

.data
.balign 32
.globl _entry_905
_entry_905:
	.quad 4607182418800018313
/* end data */

.bss
.balign 64
.globl _entry_906
_entry_906:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_907
_entry_907:
	.ascii "catalog-0907"
/* end data */

.data
.balign 64
.globl _entry_908
_entry_908:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_909
_entry_909:
	.byte 116
/* end data */

.data
.balign 2
.globl _entry_910
_entry_910:
	.short 37385
/* end data */

.data
.balign 4
.globl _entry_911
_entry_911:
	.int 2207189677
/* end data */

.data
.balign 8
.globl _entry_912
_entry_912:
	.quad -81985529222003824
/* end data */

.data
.balign 16
.globl _entry_913
_entry_913:
	.int 1065354129
/* end data */

.data
.balign 32
.globl _entry_914
_entry_914:
	.quad 4607182418800018322
/* end data */

.bss
.balign 64
.globl _entry_915
_entry_915:
	.fill 6,1,0
/* end data */

.data
.balign 64
.globl _entry_916
_entry_916:
	.ascii "catalog-0916"
/* end data */

.data
.balign 64
.globl _entry_917
_entry_917:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_918
_entry_918:
	.byte 193
/* end data */

.data
.balign 2
.globl _entry_919
_entry_919:
	.short 39698
/* end data */

.data
.balign 4
.globl _entry_920
_entry_920:
	.int 2207779528
/* end data */

.data
.balign 8
.globl _entry_921
_entry_921:
	.quad -81985529222003815
/* end data */

.data
.balign 16
.globl _entry_922
_entry_922:
	.int 1065354138
/* end data */

.data
.balign 32
.globl _entry_923
_entry_923:
	.quad 4607182418800018331
/* end data */

.bss
.balign 64
.globl _entry_924
_entry_924:
	.fill 2,1,0
/* end data */

.data
.balign 64
.globl _entry_925
_entry_925:
	.ascii "catalog-0925"
/* end data */

.data
.balign 64
.globl _entry_926
_entry_926:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_927
_entry_927:
	.byte 14
/* end data */

.data
.balign 2
.globl _entry_928
_entry_928:
	.short 42011
/* end data */

.data
.balign 4
.globl _entry_929
_entry_929:
	.int 2208369379
/* end data */

.data
.balign 8
.globl _entry_930
_entry_930:
	.quad -81985529222003806
/* end data */

.data
.balign 16
.globl _entry_931
_entry_931:
	.int 1065354147
/* end data */

.data
.balign 32
.globl _entry_932
_entry_932:
	.quad 4607182418800018340
/* end data */

.bss
.balign 64
.globl _entry_933
_entry_933:
	.fill 11,1,0
/* end data */

.data
.balign 64
.globl _entry_934
_entry_934:
	.ascii "catalog-0934"
/* end data */

.data
.balign 64
.globl _entry_935
_entry_935:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_936
_entry_936:
	.byte 91
/* end data */

.data
.balign 2
.globl _entry_937
_entry_937:
	.short 44324
/* end data */

.data
.balign 4
.globl _entry_938
_entry_938:
	.int 2208959230
/* end data */

.data
.balign 8
.globl _entry_939
_entry_939:
	.quad -81985529222003797
/* end data */

.data
.balign 16
.globl _entry_940
_entry_940:
	.int 1065354156
/* end data */

.data
.balign 32
.globl _entry_941
_entry_941:
	.quad 4607182418800018349
/* end data */

.bss
.balign 64
.globl _entry_942
_entry_942:
	.fill 7,1,0
/* end data */

.data
.balign 64
.globl _entry_943
_entry_943:
	.ascii "catalog-0943"
/* end data */

.data
.balign 64
.globl _entry_944
_entry_944:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_945
_entry_945:
	.byte 168
/* end data */

.data
.balign 2
.globl _entry_946
_entry_946:
	.short 46637
/* end data */

.data
.balign 4
.globl _entry_947
_entry_947:
	.int 2209549081
/* end data */

.data
.balign 8
.globl _entry_948
_entry_948:
	.quad -81985529222003788
/* end data */

.data
.balign 16
.globl _entry_949
_entry_949:
	.int 1065354165
/* end data */

.data
.balign 32
.globl _entry_950
_entry_950:
	.quad 4607182418800018358
/* end data */

.bss
.balign 64
.globl _entry_951
_entry_951:
	.fill 3,1,0
/* end data */

.data
.balign 64
.globl _entry_952
_entry_952:
	.ascii "catalog-0952"
/* end data */

.data
.balign 64
.globl _entry_953
_entry_953:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_954
_entry_954:
	.byte 245
/* end data */

.data
.balign 2
.globl _entry_955
_entry_955:
	.short 48950
/* end data */

.data
.balign 4
.globl _entry_956
_entry_956:
	.int 2210138932
/* end data */

.data
.balign 8
.globl _entry_957
_entry_957:
	.quad -81985529222003779
/* end data */

.data
.balign 16
.globl _entry_958
_entry_958:
	.int 1065354174
/* end data */

.data
.balign 32
.globl _entry_959
_entry_959:
	.quad 4607182418800018367
/* end data */

.bss
.balign 64
.globl _entry_960
_entry_960:
	.fill 12,1,0
/* end data */

.data
.balign 64
.globl _entry_961
_entry_961:
	.ascii "catalog-0961"
/* end data */

.data
.balign 64
.globl _entry_962
_entry_962:
	.quad _entry_0+3
/* end data */

.data
.balign 1
.globl _entry_963
_entry_963:
	.byte 66
/* end data */

.data
.balign 2
.globl _entry_964
_entry_964:
	.short 51263
/* end data */

.data
.balign 4
.globl _entry_965
_entry_965:
	.int 2210728783
/* end data */

.data
.balign 8
.globl _entry_966
_entry_966:
	.quad -81985529222003770
/* end data */

.data
.balign 16
.globl _entry_967
_entry_967:
	.int 1065354183
/* end data */

.data
.balign 32
.globl _entry_968
_entry_968:
	.quad 4607182418800018376
/* end data */

.bss
.balign 64
.globl _entry_969
_entry_969:
	.fill 8,1,0
/* end data */

.data
.balign 64
.globl _entry_970
_entry_970:
	.ascii "catalog-0970"
/* end data */

.data
.balign 64
.globl _entry_971
_entry_971:
	.quad _entry_0+5
/* end data */

.data
.balign 1
.globl _entry_972
_entry_972:
	.byte 143
/* end data */

.data
.balign 2
.globl _entry_973
_entry_973:
	.short 53576
/* end data */

.data
.balign 4
.globl _entry_974
_entry_974:
	.int 2211318634
/* end data */

.data
.balign 8
.globl _entry_975
_entry_975:
	.quad -81985529222003761
/* end data */

.data
.balign 16
.globl _entry_976
_entry_976:
	.int 1065354192
/* end data */

.data
.balign 32
.globl _entry_977
_entry_977:
	.quad 4607182418800018385
/* end data */

.bss
.balign 64
.globl _entry_978
_entry_978:
	.fill 4,1,0
/* end data */

.data
.balign 64
.globl _entry_979
_entry_979:
	.ascii "catalog-0979"
/* end data */

.data
.balign 64
.globl _entry_980
_entry_980:
	.quad _entry_0+0
/* end data */

.data
.balign 1
.globl _entry_981
_entry_981:
	.byte 220
/* end data */

.data
.balign 2
.globl _entry_982
_entry_982:
	.short 55889
/* end data */

.data
.balign 4
.globl _entry_983
_entry_983:
	.int 2211908485
/* end data */

.data
.balign 8
.globl _entry_984
_entry_984:
	.quad -81985529222003752
/* end data */

.data
.balign 16
.globl _entry_985
_entry_985:
	.int 1065354201
/* end data */

.data
.balign 32
.globl _entry_986
_entry_986:
	.quad 4607182418800018394
/* end data */

.bss
.balign 64
.globl _entry_987
_entry_987:
	.fill 13,1,0
/* end data */

.data
.balign 64
.globl _entry_988
_entry_988:
	.ascii "catalog-0988"
/* end data */

.data
.balign 64
.globl _entry_989
_entry_989:
	.quad _entry_0+2
/* end data */

.data
.balign 1
.globl _entry_990
_entry_990:
	.byte 41
/* end data */

.data
.balign 2
.globl _entry_991
_entry_991:
	.short 58202
/* end data */

.data
.balign 4
.globl _entry_992
_entry_992:
	.int 2212498336
/* end data */

.data
.balign 8
.globl _entry_993
_entry_993:
	.quad -81985529222003743
/* end data */

.data
.balign 16
.globl _entry_994
_entry_994:
	.int 1065354210
/* end data */

.data
.balign 32
.globl _entry_995
_entry_995:
	.quad 4607182418800018403
/* end data */

.bss
.balign 64
.globl _entry_996
_entry_996:
	.fill 9,1,0
/* end data */

.data
.balign 64
.globl _entry_997
_entry_997:
	.ascii "catalog-0997"
/* end data */

.data
.balign 64
.globl _entry_998
_entry_998:
	.quad _entry_0+4
/* end data */

.data
.balign 1
.globl _entry_999
_entry_999:
	.byte 118
/* end data */

.data
.balign 2
.globl _entry_1000
_entry_1000:
	.short 60515
/* end data */

.data
.balign 4
.globl _entry_1001
_entry_1001:
	.int 2213088187
/* end data */

.data
.balign 8
.globl _entry_1002
_entry_1002:
	.quad -81985529222003734
/* end data */

.data
.balign 16
.globl _entry_1003
_entry_1003:
	.int 1065354219
/* end data */

.data
.balign 32
.globl _entry_1004
_entry_1004:
	.quad 4607182418800018412
/* end data */

.bss
.balign 64
.globl _entry_1005
_entry_1005:
	.fill 5,1,0
/* end data */

.data
.balign 64
.globl _entry_1006
_entry_1006:
	.ascii "catalog-1006"
/* end data */

.data
.balign 64
.globl _entry_1007
_entry_1007:
	.quad _entry_0+6
/* end data */

.data
.balign 1
.globl _entry_1008
_entry_1008:
	.byte 195
/* end data */

.data
.balign 2
.globl _entry_1009
_entry_1009:
	.short 62828
/* end data */

.data
.balign 4
.globl _entry_1010
_entry_1010:
	.int 2213678038
/* end data */

.data
.balign 8
.globl _entry_1011
_entry_1011:
	.quad -81985529222003725
/* end data */

.data
.balign 16
.globl _entry_1012
_entry_1012:
	.int 1065354228
/* end data */

.data
.balign 32
.globl _entry_1013
_entry_1013:
	.quad 4607182418800018421
/* end data */

.bss
.balign 64
.globl _entry_1014
_entry_1014:
	.fill 1,1,0
/* end data */

.data
.balign 64
.globl _entry_1015
_entry_1015:
	.ascii "catalog-1015"
/* end data */

.data
.balign 64
.globl _entry_1016
_entry_1016:
	.quad _entry_0+1
/* end data */

.data
.balign 1
.globl _entry_1017
_entry_1017:
	.byte 16
/* end data */

.data
.balign 2
.globl _entry_1018
_entry_1018:
	.short 65141
/* end data */

.data
.balign 4
.globl _entry_1019
_entry_1019:
	.int 2214267889
/* end data */

.data
.balign 8
.globl _entry_1020
_entry_1020:
	.quad -81985529222003716
/* end data */

.data
.balign 16
.globl _entry_1021
_entry_1021:
	.int 1065354237
/* end data */

.data
.balign 32
.globl _entry_1022
_entry_1022:
	.quad 4607182418800018430
/* end data */

.bss
.balign 64
.globl _entry_1023
_entry_1023:
	.fill 10,1,0
/* end data */

.data
.balign 64
.globl _entry_1024
_entry_1024:
	.ascii "catalog-1024"
/* end data */

