long control(void) { return 37; }
